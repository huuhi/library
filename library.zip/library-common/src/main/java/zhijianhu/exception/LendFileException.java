package zhijianhu.exception;

/**
 * @author 胡志坚
 * @version 1.0
 * 创造日期 2025/2/28
 * 说明:
 */
public class LendFileException extends BaseException{
    public LendFileException(String msg){
        super(msg);
    }

}
