package zhijianhu.constant;

/**
 * @author 胡志坚
 * @version 1.0
 * 创造日期 2025/3/9
 * 说明:
 */
public class Level {
    public static final String LEVEL_1="none";
    public static final String LEVEL_2="low";
    public static final String LEVEL_3="medium";
    public static final String LEVEL_4="high";
}
