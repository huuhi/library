package zhijianhu.libraryserver.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import zhijianhu.entity.Publish;

/**
* @author windows
* @description 针对表【publish】的数据库操作Mapper
* @createDate 2025-02-28 14:40:35
* @Entity zhijianhu.Publish
*/
public interface PublishMapper extends BaseMapper<Publish> {

}




